# scode_bot - by siwy-dev
-------- Po więcej wpadaj na discorda: https://discord.gg/E499Hx8Xkq --------

# ogólne informacje
1. Jak ci sie chce to se możesz po dodawać funkcje w s_bot\server\events
2. Po Pomoc bądź dodatkowe funkcje zgłoś się na discordzie!



# Miłego dzionka życze :D